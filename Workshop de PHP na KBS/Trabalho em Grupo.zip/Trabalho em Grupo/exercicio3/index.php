<!DOCTYPE html>
<html>
<head>
	<title>Exercico 3</title>
</head>
<body>
	<center>
		<h3>Exercicio 3</h3>
		<form action="php/verificar.php" method="post">
			Digite uma palavra: <input type="text" name="palavra">
			<input type="submit" name="verificar" value="Verificar">
		</form>
	</center>
</body>
</html>