<!DOCTYPE html>
<html>
<head>
	<title>Exercicio 5</title>
</head>
<body>
	<center>
		<form action="php/processar.php" method="post">
			Username: <input type="text" name="user">
			Password: <input type="password" name="pass"><br>
			<input type="submit" name="login" value="Aceder">
			
		</form>
	</center>

</body>
</html>