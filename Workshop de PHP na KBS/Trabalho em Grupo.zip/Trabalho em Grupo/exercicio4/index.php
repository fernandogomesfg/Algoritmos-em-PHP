<!DOCTYPE html>
<html>
<head>
	<title>Exercicio 4</title>
</head>
<body>
	<center>
		<h3>Tabuada</h3>
		<form action="php/calcular.php" method="post">
			Escolha a tabuada: <input type="number" name="numero" min="1">
			<input type="submit" name="calcular" value="Calcular">
		</form>
	</center>

</body>
</html>